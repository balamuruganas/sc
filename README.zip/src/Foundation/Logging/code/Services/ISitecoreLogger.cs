﻿using System;
using System.Runtime.CompilerServices;

namespace ACG.Foundation.Logging.Services
{
    public interface ISitecoreLogger
    {
        void Info(string message, [CallerMemberName] string callerName = "", [CallerLineNumber] int lineNumber = 0, [CallerFilePath] string path = "");

        void Warning(string message, Exception e = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int lineNumber = 0, [CallerFilePath] string path = "");

        void Error(string message, Exception e, [CallerMemberName] string callerName = "", [CallerLineNumber] int lineNumber = 0, [CallerFilePath] string path = "");

        void Debug(string message, [CallerMemberName] string callerName = "", [CallerLineNumber] int lineNumber = 0, [CallerFilePath] string path = "");
    }
}
