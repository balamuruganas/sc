﻿using System;
using System.Runtime.CompilerServices;
using log4net;
using System.Text;
using ACG.Foundation.DependencyInjection;

namespace ACG.Foundation.Logging.Services
{
    [Service(typeof(ISitecoreLogger), Lifetime = Lifetime.Transient)]
    public class SitecoreLogger : ISitecoreLogger
    {
        private static ILog _log;
        public static ILog Log => _log ?? (_log = LogManager.GetLogger(typeof(SitecoreLogger)));

        public void Info(string message, [CallerMemberName] string callerName = "", [CallerLineNumber] int lineNumber = 0, [CallerFilePath] string path = "")
        {
            Log.Info(BuildMessage(message, callerName, path, lineNumber));
        }

        public void Warning(string message, Exception e = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int lineNumber = 0, [CallerFilePath] string path = "")
        {
            if (e == null)
                Log.Warn(BuildMessage(message, callerName, path, lineNumber));
            else
                Log.Warn(BuildMessage(message, callerName, path, lineNumber), e);
        }

        public void Error(string message, Exception e, [CallerMemberName] string callerName = "", [CallerLineNumber] int lineNumber = 0, [CallerFilePath] string path = "")
        {
            Log.Error(BuildMessage(message, callerName, path, lineNumber), e);
        }

        public void Debug(string message, [CallerMemberName] string callerName = "", [CallerLineNumber] int lineNumber = 0, [CallerFilePath] string path = "")
        {
            Log.Debug(BuildMessage(message, callerName, path, lineNumber));
        }

        private string BuildMessage(string message, string method, string fileName, int lineNumber)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"QM Log: '{message}' ");
            sb.AppendLine($"REFERENCE File: '{fileName}'. LINE #: '{lineNumber}'. METHOD: '{method}'");
            return sb.ToString();
        }
    }
}