﻿using Microsoft.Extensions.DependencyInjection;
using Sitecore.DependencyInjection;

namespace ACG.Foundation.DependencyInjection.Infrastructure
{
    public class MvcControllerServicesConfigurator : IServicesConfigurator
    {
        public void Configure(IServiceCollection serviceCollection)
        {
            serviceCollection.AddMvcControllers("ACG.Feature.*");
            serviceCollection.AddClassesWithServiceAttribute("ACG.Feature.*");
            serviceCollection.AddClassesWithServiceAttribute("ACG.Foundation.*");
        }
    }
}