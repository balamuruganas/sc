﻿using ACG.Foundation.Logging.Services;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using Sitecore;
using Sitecore.Diagnostics;
using Sitecore.LayoutService.Configuration;
using Sitecore.LayoutService.ItemRendering.ContentsResolvers;
using Sitecore.Mvc.Presentation;
using System.Diagnostics.CodeAnalysis;

namespace ACG.Foundation.JavaScriptServices
{
    /// <summary>
    /// this is base resolver need to be inheriated by all components content resolvers
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class BaseResolver : RenderingContentsResolver
    {

        private ISitecoreLogger Logger { get; set; }

        public BaseResolver(ISitecoreLogger logger)
        {
            Logger = logger;
        }

        /// <summary>
        /// This is base resolver will be hit by Sitecore.. 
        /// </summary>
        /// <param name="rendering"></param>
        /// <param name="renderingConfig"></param>
        /// <returns></returns>
        public override object ResolveContents(Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            Assert.ArgumentNotNull(renderingConfig, "renderingConfig");

            Sitecore.Data.Items.Item contextItem = GetContextItem(rendering, renderingConfig);
            if (contextItem == null)
            {
                Logger.Info(rendering.RenderingItem.DisplayName + " Datasource / ContextItem is Null Or Empty" + " On " + Context.Item.Name);
                return null;
            }

            if (rendering == null)
            {
                return string.Empty;
            }

            var result = ResolveContentSSR(rendering, renderingConfig);
            JObject resultJobject = new JObject();

            if (result != null)
            {
                CamelCasePropertyNamesContractResolver contractResolver = new CamelCasePropertyNamesContractResolver
                {
                    NamingStrategy = new CamelCaseNamingStrategy
                    {
                        OverrideSpecifiedNames = false,
                        ProcessDictionaryKeys = false
                    }
                };
                var serializer = new JsonSerializer()
                {
                    ContractResolver = contractResolver
                };

                resultJobject = new JObject
                {
                    ["data"] = JObject.FromObject(result, serializer).GetValue("data")
                };
            }
            return resultJobject;
        }

        /// <summary>
        /// This function need to be override in every component resolver. 
        /// </summary>
        /// <param name="rendering"></param>
        /// <param name="renderingConfig"></param>
        /// <returns></returns>
        public virtual object ResolveContentSSR(Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            Logger.Warning(string.Format("BaseResolver: {0} Component doesnt implement ResolveContentSSR.", rendering.Item.Name));
            return null;
        }

    }
}

