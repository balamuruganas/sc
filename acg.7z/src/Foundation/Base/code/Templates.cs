﻿using Sitecore.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ACG.Foundation.Base
{
    public struct Templates
    {
		public struct Enum
		{
			public struct Fields
			{
				public static ID Value { get; } = new ID("{87914A66-ACBA-4745-B816-11AE2C684107}");

			}

			public static readonly ID ID = ID.Parse("{E6BFFA81-386A-4B54-954F-A6DC3C7E6914}");
		}
	}
}