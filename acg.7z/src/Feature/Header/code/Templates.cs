﻿using Sitecore.Data;

namespace ACG.Feature.Header
{
    public static class Templates
    {
        public static class _Navigable
        {
            public static readonly ID TemplateId = new ID("{DD71BE44-7655-4A0B-ADC6-9D99F2BE58A1}");

            public static class Fields
            {
                public static readonly ID NavigationTitle = new ID("{6D88C1E8-9237-4986-BB65-48454845F65D}");
                public static readonly ID NavigationFilter = new ID("{300D0039-BB17-44F0-806A-7D347A713033}");
                public static readonly ID RedirectUrl = new ID("{41F2FA54-320A-4F9A-ADAB-5F983B55266B}");
            }
        }

        public static class Parameters_Navigable
        {
            public static class FieldNames
            {
                public static readonly string NavigationRoot = "NavigationRoot";
                public static readonly string Filter = "Filter";
                public static readonly string AddRoot = "AddRoot";
                public static readonly string Levels = "Levels";
            }
        }
    }
}