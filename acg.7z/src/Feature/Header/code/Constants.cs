﻿namespace ACG.Feature.Header
{
    public class Constants
    {
        public const string SiteHomeNavigationTitle = "Home";
    }
}