﻿using Newtonsoft.Json;
using Sitecore.Data;
using System.Collections.Generic;
using System.ComponentModel;

namespace ACG.Feature.Header.Models
{
    public class NavigationItemModel
    {
        public ID Id { get; set; }
        public string Url { get; set; }
        public string NavigationTitle { get; set; }
        public string RedirectUrl { get; set; }
        public string RedirectUrlTarget { get; set; }
        public List<NavigationItemModel> Children { get; set; }
    }
    public class NavigationData
    {
        [DefaultValue("")]
        [JsonProperty(PropertyName = "data", DefaultValueHandling = DefaultValueHandling.Populate)]
        public NavigationJsonModel Data { get; set; }
    }
    public class NavigationJsonModel
    {
        [DefaultValue("")]
        [JsonProperty(PropertyName = "navs", DefaultValueHandling = DefaultValueHandling.Populate)]
        public List<NavigationItemModel> Items { get; set; }
    }
}