﻿using ACG.Feature.Header.Models;
using ACG.Foundation.JavaScriptServices;
using ACG.Foundation.Logging.Services;
using Newtonsoft.Json.Linq;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Data.Managers;
using Sitecore.Data.Templates;
using Sitecore.Diagnostics;
using Sitecore.LayoutService.Configuration;
using Sitecore.Mvc.Presentation;
using System.Collections.Generic;
using System.Linq;
using Sitecore.LayoutService.ItemRendering.ContentsResolvers;
using Sitecore.Data.Fields;
using System.Globalization;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace ACG.Feature.Header.ContentsResolvers
{
    /// <summary>
    /// Contents Resolver for Navigation Items
    /// </summary>
    public class NavigationContentsResolver : RenderingContentsResolver
    {
        public NavigationContentsResolver() { }

        public override object ResolveContents(Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            Assert.ArgumentNotNull(rendering, "rendering");
            Assert.ArgumentNotNull(renderingConfig, "renderingConfig");

            Item navigationRoot = Sitecore.Context.Database.GetItem(rendering.Parameters[Templates.Parameters_Navigable.FieldNames.NavigationRoot]);

            if (navigationRoot == null)
            {
                return null;
            }

            JObject jobject = new JObject()
            {
                ["items"] = (JToken)new JArray()
            };

            // First page under our site root should be Home
            var addRoot = rendering.Parameters[Templates.Parameters_Navigable.FieldNames.AddRoot] == "1";
            var navigationType = rendering.Parameters[Templates.Parameters_Navigable.FieldNames.Filter];

            int intNavDepth = ParseLevel(rendering, "Levels");

            var result = new NavigationData()
            {
                Data = new NavigationJsonModel()
                {
                    Items = GetNavigation(navigationRoot, addRoot, navigationType, intNavDepth)
                }
            };

            JObject resultJobject = new JObject();

            if (result != null)
            {
                CamelCasePropertyNamesContractResolver contractResolver = new CamelCasePropertyNamesContractResolver
                {
                    NamingStrategy = new CamelCaseNamingStrategy
                    {
                        OverrideSpecifiedNames = false,
                        ProcessDictionaryKeys = false
                    }
                };
                var serializer = new JsonSerializer()
                {
                    ContractResolver = contractResolver
                };

                resultJobject = new JObject
                {
                    ["data"] = JObject.FromObject(result, serializer).GetValue("data")
                };
            }
            return resultJobject;
        }

        public IList<ID> GetBaseTemplates(ID templateId, Database database)
        {
            Template template = TemplateManager.GetTemplate(templateId, database);
            if (template != null)
            {
                return (from t in template.GetBaseTemplates()
                        select t.ID).ToList();
            }
            return new List<ID>();
        }

        /// <summary>
        /// Return matching items list
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="addRoot"></param>
        /// <param name="navigationFilter"></param>
        /// <param name="depth"></param>
        /// <returns></returns>
        private List<NavigationItemModel> GetNavigation(Item parent, bool addRoot, string navigationFilter, int depth)
        {
            var navItems = new List<NavigationItemModel>();

            if (parent == null)
            {
                Log.Info("NavigationContentResolver: Navigation root is not set.", typeof(NavigationContentsResolver));
                return navItems;
            }

            if (string.IsNullOrEmpty(navigationFilter))
            {
                Log.Info("NavigationContentResolver: Navigation filter is not set.", typeof(NavigationContentsResolver));
                return navItems;
            }

            // First page under our site root should be Home
            if (addRoot && IsNavigationFilter(parent, navigationFilter))
            {
                navItems.Add(new NavigationItemModel
                {
                    Id = parent.ID,
                    Url = Sitecore.Links.LinkManager.GetItemUrl(parent),
                    NavigationTitle = Constants.SiteHomeNavigationTitle
                });
            }

            depth--;

            // Get the child nav items
            var childNavItems = parent.Children.Where(n => IsNavigable(n) && IsNavigationFilter(n, navigationFilter))
                                .Select(item =>
                                    new NavigationItemModel
                                    {
                                        Id = item.ID,
                                        Url = Sitecore.Links.LinkManager.GetItemUrl(item),
                                        NavigationTitle = item[Templates._Navigable.Fields.NavigationTitle],
                                        Children = (depth > 0) ? GetNavigation(item, false, navigationFilter, depth) : new List<NavigationItemModel>()
                                    });

            if (childNavItems != null && childNavItems.Count() > 0)
            {
                navItems.AddRange(childNavItems);
            }

            return navItems;
        }


        protected virtual int ParseLevel(Rendering rendering, string fieldName)
        {
            string enumValue = GetEnumValue(rendering.Parameters, fieldName);
            if (!string.IsNullOrWhiteSpace(enumValue))
            {
                return int.Parse(enumValue, CultureInfo.InvariantCulture);
            }
            return -1;
        }

        private string GetEnumValue(RenderingParameters parameters, string parameterName)
        {
            Field field = Sitecore.Context.Database.GetItem(parameters[parameterName])?.Fields[ACG.Foundation.Base.Templates.Enum.Fields.Value];
            if (field != null)
            {
                return field.Value;
            }
            return string.Empty;
        }

        private bool IsNavigable(Item item)
        {
            if (item == null) return false;
            return GetBaseTemplates(item.TemplateID, item.Database).Contains(Templates._Navigable.TemplateId);
        }

        private bool IsNavigationFilter(Item item, string filter) => (item[Templates._Navigable.Fields.NavigationFilter].Contains(filter));

    }
}
