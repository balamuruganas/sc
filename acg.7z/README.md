https://konabos.com/blog/setting-up-sitecore-serialization-using-sitecore-cli

dotnet new tool-manifest
dotnet tool install Sitecore.CLI --add-source https://sitecore.myget.org/F/sc-packages/api/v3/index.json

dotnet sitecore init

dotnet sitecore login --authority https://allstateidentityserver.dev.local --cm https://allstatecm.dev.local --allow-write true